# Khalil: start here

Your part of ELE IDSA Project 1:
- the **3 hypothesis charts and tests** (H1, H2, H3)
- the **Results & Discussion** text for them
- the **Conclusion**

Everything you and your Claude need is in this folder. The data is already cleaned.

## What's in this folder

| File | What it is |
|---|---|
| `START_HERE.md` | this guide |
| `PROMPT.txt` | the message to paste into Claude |
| `CONTEXT.md` | project background, hypotheses, column meanings and rules for Claude |
| `project.py` | shared code: loads the data and gives every chart the group's style |
| `route801_events.csv.gz` | the cleaned dataset (keep it zipped as `.gz`; Claude reads it directly) |
| `requirements.txt` | Python packages, only needed if you run it on your laptop |
| `reference/02_methodology.md` | the Methodology section (how the data was cleaned) |
| `reference/03b_results_heatmap.md` | Rence's results on where and when people board |

## Option A: claude.ai chat or Claude Code on the web

**claude.ai chat**
1. Unzip this folder.
2. Open a **new chat** on claude.ai.
3. **Upload these 5 files:** `CONTEXT.md`, `project.py`, `route801_events.csv.gz`, `reference/02_methodology.md`, `reference/03b_results_heatmap.md`.
4. Open `PROMPT.txt`, copy all of it, and paste it as your message.
5. Claude runs the code and gives you the files to download:
   - `03_hypotheses.ipynb`
   - `fig06_h1_load_vs_headway.png`, `fig07_h2_dwell_vs_boardings.png`, `fig08_h3_headway_cv_by_stop.png`
   - `05_results_hypotheses.md`, `06_conclusion.md`
6. **Look at the 3 charts yourself.** If a label is cut off, text overlaps, or something is hard to read, tell Claude what to fix.
7. Send all the files to Rence. Or, if you have access to the GitHub repo, upload them there:
   - notebook → `notebooks/`
   - PNGs → `figures/`
   - `.md` files → `report/sections/`

If Claude says the code can't run, check that **code execution / analysis** is turned on in your Claude settings.

**Claude Code with repo access:** you don't need this zip. Open `RJL-Marquez/ELE-IDSA-PROJECT-1` and paste your prompt from `TASKS.md` in the repo.

## Option B: your laptop (Claude Code or Jupyter)

```bash
pip install -r requirements.txt
```

Then open Claude Code in this folder and paste `PROMPT.txt`. The steps are the same as Option A.
