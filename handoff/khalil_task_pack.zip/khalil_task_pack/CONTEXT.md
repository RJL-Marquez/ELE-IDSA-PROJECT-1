# Project context (for Claude)

## The project

Group report for a Data Science and Analytics course (ELE IDSA Project 1, section GEC2B, instructor Ezron John D. Cabrera). The group members are Rence, Khalil and Elijah. **This chat is Khalil's part:** the hypothesis tests, their charts and discussion, and the Conclusion.

**Title:** *Why Buses Bunch: the relationship between passenger demand and bus bunching on CapMetro Rapid Route 801 (Austin, Texas), July–December 2021.*

**Hypotheses (use exactly this wording)**
- **H1:** Buses with a longer gap behind the bus ahead (headway) carry more passengers.
- **H2:** The more people board and alight, the longer the bus stays at the stop (dwell time).
- **H3:** Headways become more irregular further along the route (bunching builds up).

**What the instructor grades (rubric weight)**
- Introduction ×2: written by Elijah.
- Methodology ×2: written by Rence.
- **Results & Discussion ×4: correct, readable, good-looking plots (axis labels, units, tick marks).**
- **Conclusion ×2: main takeaways in bullet points that summarize the whole report.**

The final report may become slides or a paper. Write text as **short Markdown with bullets** so it works for both.

## Facts about the data

- **Source:** CapMetro (Austin, Texas), *APC Raw July 2021 – December 2021*, Texas Open Data Portal, ID `im6q-3pc9`.
- **APC = automatic passenger counters:** door sensors count people getting on and off, and GPS and the clock record each stop. One row = one bus at one stop.
- **Study data:** Route 801 southbound, July 1 – December 30, 2021. That's 229,421 stop records, 29 stops and 143 buses.
- **Schedule:** a bus every 10 minutes on weekdays from 7:00 to 18:00.
- **Cleaning** (details in `02_methodology.md`):
  - six filtering rules
  - duplicates removed
  - layovers at the two end stops removed
  - impossible counts and dwell times above 10 minutes imputed with the median of the same stop and hour
  - headways kept only between buses scheduled exactly 10 minutes apart, because some trips are missing from the data

## Loading the data

The uploaded files are in your working directory. Find their folder, then:

```python
import sys; sys.path.insert(0, "<folder containing project.py>")
from project import load_events, window, new_fig, finish, save, COLORS, SERIES, SOURCE_NOTE
ev = load_events("<folder>/route801_events.csv.gz")   # 229,414 rows, already cleaned
w  = window(ev)                                       # weekdays 7:00-17:59 only (use this for all tests)
# save charts with: save(fig, "fig06_h1_load_vs_headway", folder="<output folder>")
```

**Columns**

| Column | Meaning |
|---|---|
| `service_day` | service date |
| `arrival` | time the doors opened |
| `hour` | hour of day, 0–23 |
| `day_type` | "Weekday" or "Weekend" |
| `in_window` | True if weekday 7:00–17:59 |
| `stop_id` | stop ID |
| `stop_order` | position on the route: 1 (first) to 29 (last) |
| `is_terminal` | True for the two end stops (1 and 29) |
| `ons`, `offs` | passengers boarding / alighting at this stop |
| `max_load` | passengers on board after the stop |
| `dwell_time` | seconds the doors were open (cleaned; NaN at the end stops) |
| `headway_s` | seconds since the previous bus at this stop. NaN when there is no valid value: at end stops, for the first bus, or when the previous recorded bus was not scheduled 10 minutes earlier. |

## Rules

1. **Do not clean the data again.**
2. **Charts:**
   - Always use `new_fig()`, `finish(ax, title, xlabel, ylabel, note=SOURCE_NOTE)` and `save(...)`.
   - Every axis label has units.
   - Use only the `COLORS`/`SERIES` colours, in order: blue, orange, aqua.
   - No dual y-axes.
   - Don't put a number on every bar or point; label only the important ones.
   - After saving, look at each chart and fix overlapping or cut-off text.
3. **Every number in the text must come from the code's printed output.** Never estimate or invent numbers.
4. **Keep text short:** bullets and 1–3 sentence paragraphs. The rubric penalizes wordiness.
