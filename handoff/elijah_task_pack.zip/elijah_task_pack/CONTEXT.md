# Project context (for Claude)

## The project

Group report for a Data Science and Analytics course (ELE IDSA Project 1, section GEC2B, instructor Ezron John D. Cabrera). The group members are Rence, Khalil and Elijah. **This chat is Elijah's part.**

**Title:** *Why Buses Bunch: the relationship between passenger demand and bus bunching on CapMetro Rapid Route 801 (Austin, Texas), July–December 2021.*

**Hypotheses (use exactly this wording)**
- **H1:** Buses with a longer gap behind the bus ahead (headway) carry more passengers.
- **H2:** The more people board and alight, the longer the bus stays at the stop (dwell time).
- **H3:** Headways become more irregular further along the route (bunching builds up).

**What the instructor grades (rubric weight)**
- Introduction/Motivation ×2: background well explained, briefly.
- Methodology ×2: written by Rence.
- **Results & Discussion ×4: correct, readable, good-looking plots (axis labels, units, tick marks).**
- Conclusion ×2: written by Khalil.

The final report may become slides or a paper. Write text as **short Markdown with bullets** so it works for both.

## Facts about the data (for the Introduction)

- **Source:** Capital Metropolitan Transportation Authority (CapMetro), Austin, Texas, USA. Dataset *APC Raw July 2021 – December 2021*, Texas Open Data Portal, ID `im6q-3pc9`, free and public.
- **APC = automatic passenger counters.**
  - Sensors at bus doors count people getting on and off.
  - GPS and the bus clock record when and where each stop happens.
  - One row = one bus stopping at one stop.
- **Size:**
  - The raw file has 9,197,694 rows covering every CapMetro route.
  - The study uses Route 801 southbound: 229,421 stop records, 29 stops, 143 buses, July 1 – December 30, 2021.
- **Route 801:** a CapMetro Rapid (high-frequency) line, scheduled every 10 minutes on weekdays from 7:00 to 18:00.
- **Bus bunching:** buses lose their even spacing and arrive in pairs, followed by a long gap.
  - A late bus finds more people waiting, takes longer at stops, and falls further behind.
  - Meanwhile the bus behind it catches up.
  - Riders wait longer, and some buses are crowded while others run nearly empty.

## Loading the data

The uploaded files are in your working directory. Find their folder, then:

```python
import sys; sys.path.insert(0, "<folder containing project.py>")
from project import load_events, window, new_fig, finish, save, COLORS, SERIES, SOURCE_NOTE
ev = load_events("<folder>/route801_events.csv.gz")   # 229,414 rows, already cleaned
w  = window(ev)                                       # weekdays 7:00-17:59 only
# save charts with: save(fig, "fig03_boardings_by_hour", folder="<output folder>")
```

**Columns**

| Column | Meaning |
|---|---|
| `service_day` | service date |
| `arrival` | time the doors opened |
| `hour` | hour of day, 0–23 |
| `day_type` | "Weekday" or "Weekend" |
| `in_window` | True if weekday 7:00–17:59 |
| `stop_id` | stop ID |
| `stop_order` | position on the route: 1 (first) to 29 (last) |
| `is_terminal` | True for the two end stops (1 and 29) |
| `ons`, `offs` | passengers boarding / alighting at this stop |
| `max_load` | passengers on board after the stop |
| `dwell_time` | seconds the doors were open |
| `headway_s` | seconds since the previous bus at this stop. NaN when there is no valid value: at end stops, for the first bus, or when the previous recorded bus was not scheduled 10 minutes earlier. Some trips are missing from the data, and this rule stops a missing bus from looking like a fake 20-minute gap. |

## Rules

1. **Do not clean the data again.** It's already cleaned, and the cleaning is described in `reference/02_methodology.md`.
2. **Charts:**
   - Always use `new_fig()`, `finish(ax, title, xlabel, ylabel, note=SOURCE_NOTE)` and `save(...)`.
   - Every axis label has units.
   - Use only the `COLORS`/`SERIES` colours, in order: blue, orange, aqua.
   - No dual y-axes.
   - Don't put a number on every bar or point; label only the important ones.
   - After saving, look at each chart and fix overlapping or cut-off text.
3. **Every number in the text must come from the code's printed output.** Never estimate or invent numbers.
4. **Keep text short:** bullets and 1–3 sentence paragraphs. The rubric penalizes wordiness.
