# Elijah: start here

Your part of ELE IDSA Project 1:
- **3 charts** about ridership patterns
- the **Introduction**
- short **notes under your charts**

Everything you and your Claude need is in this folder. The data is already cleaned.

## What's in this folder

| File | What it is |
|---|---|
| `START_HERE.md` | this guide |
| `PROMPT.txt` | the message to paste into Claude |
| `CONTEXT.md` | project background and rules for Claude |
| `project.py` | shared code: loads the data and gives every chart the group's style |
| `route801_events.csv.gz` | the cleaned dataset (keep it zipped as `.gz`; Claude reads it directly) |
| `requirements.txt` | Python packages, only needed if you run it on your laptop |
| `reference/02_methodology.md` | the Methodology section, so the Introduction matches it |

## Option A: claude.ai chat (easiest)

1. Unzip this folder.
2. Open a **new chat** on claude.ai.
3. **Upload these 3 files:** `CONTEXT.md`, `project.py`, `route801_events.csv.gz`.
4. Open `PROMPT.txt`, copy all of it, and paste it as your message.
5. Claude runs the code and gives you the files to download:
   - `02_ridership_patterns.ipynb`
   - `fig03_boardings_by_hour.png`, `fig04_daily_boardings.png`, `fig05_headway_distribution.png`
   - `01_introduction.md`, `03_results_ridership_patterns.md`
6. **Look at the 3 charts yourself.** If a label is cut off, text overlaps, or something is hard to read, tell Claude what to fix.
7. Send all the files to Rence. Or, if you have access to the GitHub repo, upload them there:
   - notebook → `notebooks/`
   - PNGs → `figures/`
   - `.md` files → `report/sections/`

If Claude says the code can't run, check that **code execution / analysis** is turned on in your Claude settings.

## Option B: your laptop (Claude Code or Jupyter)

```bash
pip install -r requirements.txt
```

Then open Claude Code in this folder and paste `PROMPT.txt`. The steps are the same as Option A.
